import LoginRegister from "../../components/Login_Register_components/LoginRegister";

const Login_Register = () => {
    return (
        <>
            <LoginRegister/>
        </>
    )
}

export default Login_Register;