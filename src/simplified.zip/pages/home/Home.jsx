import TitleHome from "../../components/Home_components/TitleHome";

const Home = () => {
    return (
        <>
            <TitleHome/>
        </>
    )
}

export default Home;