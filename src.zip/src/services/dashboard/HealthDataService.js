// Singleton Pattern for Health Data Service
import { HealthDataModel } from "../../models/HealthData.model";

export class HealthDataService {
  static instance;

  constructor() {
    this.data = this.generateMockData();
  }

  static getInstance() {
    if (!HealthDataService.instance) {
      HealthDataService.instance = new HealthDataService();
    }
    return HealthDataService.instance;
  }

  generateMockData() {
    const mockData = [];
    const now = new Date();

    // Generate data for the last 30 days
    for (let i = 30; i >= 0; i--) {
      const date = new Date(now);
      date.setDate(date.getDate() - i);
      
      // Generate 3-5 data points per day
      const pointsPerDay = Math.floor(Math.random() * 3) + 3;
      
      for (let j = 0; j < pointsPerDay; j++) {
        const timestamp = new Date(date);
        timestamp.setHours(8 + j * 3, Math.random() * 60, 0, 0);
        
        const heartRate = 65 + Math.floor(Math.random() * 30);
        const cigarettes = Math.floor(Math.random() * 8);
        
        mockData.push(new HealthDataModel(heartRate, cigarettes, timestamp));
      }
    }

    return mockData;
  }

  getAllData() {
    return [...this.data];
  }

  addData(data) {
    this.data.push(data);
  }

  getCurrentHeartRate() {
    if (this.data.length === 0) return 75;
    return this.data[this.data.length - 1].heartRate;
  }

  getTodayCigarettes() {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    return this.data
      .filter(item => {
        const itemDate = new Date(item.timestamp);
        itemDate.setHours(0, 0, 0, 0);
        return itemDate.getTime() === today.getTime();
      })
      .reduce((sum, item) => sum + item.cigarettesSmoked, 0);
  }
}
