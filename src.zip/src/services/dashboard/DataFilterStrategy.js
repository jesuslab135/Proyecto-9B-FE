// Strategy Pattern for filtering data by time period
import { TIME_PERIOD } from "../../constants/app.constants";

class DayFilterStrategy {
  filter(data) {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    return data.filter(item => {
      const itemDate = new Date(item.timestamp);
      itemDate.setHours(0, 0, 0, 0);
      return itemDate.getTime() === today.getTime();
    });
  }

  getLabel() {
    return 'Today';
  }
}

class WeekFilterStrategy {
  filter(data) {
    const weekAgo = new Date();
    weekAgo.setDate(weekAgo.getDate() - 7);
    
    return data.filter(item => new Date(item.timestamp) >= weekAgo);
  }

  getLabel() {
    return 'Last 7 Days';
  }
}

class MonthFilterStrategy {
  filter(data) {
    const monthAgo = new Date();
    monthAgo.setDate(monthAgo.getDate() - 30);
    
    return data.filter(item => new Date(item.timestamp) >= monthAgo);
  }

  getLabel() {
    return 'Last 30 Days';
  }
}

export class DataFilterContext {
  constructor(period) {
    this.strategy = this.getStrategy(period);
  }

  getStrategy(period) {
    switch (period) {
      case TIME_PERIOD.DAY:
        return new DayFilterStrategy();
      case TIME_PERIOD.WEEK:
        return new WeekFilterStrategy();
      case TIME_PERIOD.MONTH:
        return new MonthFilterStrategy();
      default:
        return new DayFilterStrategy();
    }
  }

  setStrategy(period) {
    this.strategy = this.getStrategy(period);
  }

  executeFilter(data) {
    return this.strategy.filter(data);
  }

  getLabel() {
    return this.strategy.getLabel();
  }
}
