import { useState, useEffect } from 'react';
import { Activity, Cigarette, TrendingDown } from 'lucide-react';
import { StatCard } from "../../components/dashboard/StatCard";
import { FilterTabs } from "../../components/dashboard/FilterTabs";
import { CigaretteChart } from "../../components/dashboard/CigaretteChart";
import { HeartRateChart } from "../../components/dashboard/HeartRateChart";
import { HealthDataService } from "../../services/HealthDataService";
import { DataFilterContext } from "../../services/DataFilterStrategy";
import { TIME_PERIOD, HEART_RATE } from "../../constants/app.constants";
import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";

const Dashboard = () => {
  const [timePeriod, setTimePeriod] = useState(TIME_PERIOD.DAY);
  const [filterContext] = useState(() => new DataFilterContext(TIME_PERIOD.DAY));
  const healthService = HealthDataService.getInstance();

  useEffect(() => {
    filterContext.setStrategy(timePeriod);
  }, [timePeriod, filterContext]);

  const allData = healthService.getAllData();
  const filteredData = filterContext.executeFilter(allData);
  const currentHeartRate = healthService.getCurrentHeartRate();
  const todayCigarettes = healthService.getTodayCigarettes();

  const avgHeartRate = filteredData.length > 0
    ? Math.round(filteredData.reduce((sum, item) => sum + item.heartRate, 0) / filteredData.length)
    : 0;

  const totalCigarettes = filteredData.reduce((sum, item) => sum + item.cigarettesSmoked, 0);

  const getHeartRateVariant = () => {
    if (currentHeartRate > HEART_RATE.WARNING_THRESHOLD) return 'danger';
    if (currentHeartRate > HEART_RATE.MAX_NORMAL) return 'warning';
    return 'success';
  };

  const getCigaretteVariant = () => {
    if (todayCigarettes > 15) return 'danger';
    if (todayCigarettes > 10) return 'warning';
    return 'default';
  };

  return (
    <div className="p-4 md:p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div>
          <h2 className="text-3xl font-bold text-foreground mb-2">Health Dashboard</h2>
          <p className="text-muted-foreground">Track your progress and stay healthy</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            title="Current Heart Rate"
            value={`${currentHeartRate} bpm`}
            subtitle={currentHeartRate > HEART_RATE.MAX_NORMAL ? 'Above normal' : 'Normal range'}
            icon={Activity}
            variant={getHeartRateVariant()}
          />
          <StatCard
            title="Today's Cigarettes"
            value={todayCigarettes}
            subtitle={`${todayCigarettes > 10 ? 'High' : 'Moderate'} consumption`}
            icon={Cigarette}
            variant={getCigaretteVariant()}
          />
          <StatCard
            title="Avg Heart Rate"
            value={`${avgHeartRate} bpm`}
            subtitle={filterContext.getLabel()}
            icon={TrendingDown}
            variant="default"
          />
          <StatCard
            title="Total Cigarettes"
            value={totalCigarettes}
            subtitle={filterContext.getLabel()}
            icon={Cigarette}
            variant="default"
          />
        </div>

        {/* Filter Tabs */}
        <FilterTabs value={timePeriod} onValueChange={setTimePeriod} />

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <HeartRateChart data={filteredData} label={filterContext.getLabel()} />
          <CigaretteChart data={filteredData} label={filterContext.getLabel()} />
        </div>

        {/* Profile Section */}
        <Card className="border-primary/20">
          <CardHeader>
            <CardTitle className="text-foreground">Profile Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-muted-foreground">Status</p>
                <p className="text-lg font-semibold text-foreground">Active User</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Goal</p>
                <p className="text-lg font-semibold text-foreground">Reduce Cravings</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Tracking Since</p>
                <p className="text-lg font-semibold text-foreground">30 days ago</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Health Score</p>
                <p className="text-lg font-semibold text-success">Good</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;
