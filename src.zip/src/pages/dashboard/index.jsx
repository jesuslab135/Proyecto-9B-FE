import { useState } from "react";
import { AppLayout } from "../../components/dashboard-layout/AppLayout";
import { LoadingScreen } from "../../components/dashboard-layout/LoadingScreen";
import { FilterTabs } from "../../components/dashboard/FilterTabs";
import { HeartRateStats } from "../../components/dashboard/HeartRateStats";
import { HeartRateChart } from "../../components/dashboard/HeartRateChart";
import { CigaretteChart } from "../../components/dashboard/CigaretteChart";
import { Card, CardContent } from "../../components/ui/card";
import { useHeartRate, useDesiresStats } from "../../hooks/useDashboard";
import { TIME_PERIOD } from "../../constants/app.constants";

export default function DashboardPage() {
  const consumidorId = 1;
  const [timePeriod, setTimePeriod] = useState(TIME_PERIOD.MONTH);
  
  const { data: heartRateData, isLoading: hrLoading } = useHeartRate(consumidorId);
  const { isLoading: desiresLoading } = useDesiresStats(consumidorId);

  if (hrLoading || desiresLoading) {
    return (
      <AppLayout>
        <LoadingScreen />
      </AppLayout>
    );
  }

  const chartData = heartRateData?.map(item => ({
    timestamp: item.window_start,
    heartRate: item.heart_rate_mean,
    cigarettesSmoked: 0
  })) || [];

  const getTimePeriodLabel = () => {
    switch(timePeriod) {
      case TIME_PERIOD.DAY: return 'Today';
      case TIME_PERIOD.WEEK: return 'This Week';
      case TIME_PERIOD.MONTH: return 'This Month';
      default: return 'Today';
    }
  };

  return (
    <AppLayout>
      <div className="min-h-screen bg-slate-100 dark:bg-slate-900">
        <div className="max-w-[1600px] mx-auto p-6 space-y-5">
          {/* Header */}
          <div className="mb-6">
            <h1 className="text-3xl font-bold text-slate-900 dark:text-white mb-1">
              Health Dashboard
            </h1>
            <p className="text-sm text-slate-600 dark:text-slate-400">
              Track your progress and stay healthy
            </p>
          </div>
          
          {/* Stats Cards */}
          <HeartRateStats consumidorId={consumidorId} />
          
          {/* Filtros de tiempo */}
          <FilterTabs value={timePeriod} onValueChange={setTimePeriod} />
          
          {/* Charts Section */}
          <div className="grid gap-5 lg:grid-cols-2">
            <HeartRateChart data={chartData} label={getTimePeriodLabel()} />
            <CigaretteChart data={chartData} label={getTimePeriodLabel()} />
          </div>
          
          {/* Profile Information Card */}
          <Card className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
            <CardContent className="p-6">
              <h2 className="text-lg font-semibold text-slate-900 dark:text-white mb-4">
                Profile Information
              </h2>
              <div className="grid grid-cols-2 gap-x-8 gap-y-4">
                <div>
                  <p className="text-xs text-slate-600 dark:text-slate-400 mb-1.5">Status</p>
                  <p className="text-sm font-semibold text-slate-900 dark:text-white">Active User</p>
                </div>
                <div>
                  <p className="text-xs text-slate-600 dark:text-slate-400 mb-1.5">Goal</p>
                  <p className="text-sm font-semibold text-slate-900 dark:text-white">Reduce Cravings</p>
                </div>
                <div>
                  <p className="text-xs text-slate-600 dark:text-slate-400 mb-1.5">Tracking Since</p>
                  <p className="text-sm font-semibold text-slate-900 dark:text-white">30 days ago</p>
                </div>
                <div>
                  <p className="text-xs text-slate-600 dark:text-slate-400 mb-1.5">Health Score</p>
                  <p className="text-sm font-semibold text-emerald-600 dark:text-emerald-400">Good</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
}
