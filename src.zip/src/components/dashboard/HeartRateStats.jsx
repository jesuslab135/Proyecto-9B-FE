import { Activity, Heart, TrendingUp, Package } from "lucide-react";
import { StatCard } from "./StatCard";
import { useHeartRateStats, useDailySummary } from "../../hooks/useDashboard";

export const HeartRateStats = ({ consumidorId }) => {
  const { data: heartRateStats } = useHeartRateStats(consumidorId);
  const { data: dailySummary } = useDailySummary(consumidorId);

  // Helper para formatear números de forma segura
  const formatValue = (value) => {
    if (!value) return "—";
    const num = typeof value === 'string' ? parseFloat(value) : value;
    return isNaN(num) ? value : num.toFixed(0);
  };

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      <StatCard
        title="Current Heart Rate"
        value={`${formatValue(dailySummary?.[0]?.hr_promedio_hoy)} bpm`}
        subtitle="Normal range"
        icon={Heart}
        variant="default"
      />
      <StatCard
        title="Today's Cigarettes"
        value="20"
        subtitle="High consumption"
        icon={Package}
        variant="danger"
      />
      <StatCard
        title="Avg Heart Rate"
        value={`${formatValue(heartRateStats?.[0]?.hr_promedio_general)} bpm`}
        subtitle="Today"
        icon={TrendingUp}
        variant="success"
      />
      <StatCard
        title="Total Cigarettes"
        value="20"
        subtitle="Today"
        icon={Activity}
        variant="warning"
      />
    </div>
  );
};
