import { Clock } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { useDesiresTracking } from "../../hooks/useDashboard";

export const DesiresTimeline = ({ consumidorId }) => {
  const { data: desiresTracking, isLoading } = useDesiresTracking(consumidorId);
  const desiresTimelineData = desiresTracking || [];

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Clock className="h-5 w-5 text-primary" />
          Deseos - Timeline
        </CardTitle>
        <CardDescription>
          Historial detallado de deseos y su resolución
        </CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="flex justify-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        ) : (
          <div className="rounded-md border">
            <div className="overflow-auto max-h-96">
              <table className="w-full">
                <thead className="bg-muted/50 sticky top-0">
                  <tr className="border-b">
                    <th className="p-3 text-left text-sm font-medium">Fecha</th>
                    <th className="p-3 text-left text-sm font-medium">Tipo</th>
                    <th className="p-3 text-center text-sm font-medium">Resuelto</th>
                    <th className="p-3 text-right text-sm font-medium">HR durante</th>
                    <th className="p-3 text-right text-sm font-medium">Prob(urge)</th>
                  </tr>
                </thead>
                <tbody>
                  {desiresTimelineData.length === 0 ? (
                    <tr>
                      <td colSpan="5" className="p-8 text-center text-muted-foreground">
                        No hay datos de timeline disponibles
                      </td>
                    </tr>
                  ) : (
                    desiresTimelineData.map((desire, idx) => (
                      <tr key={idx} className="border-b hover:bg-muted/50 transition-colors">
                        <td className="p-3 text-sm">
                          {new Date(desire.fecha_creacion).toLocaleString('es-ES', {
                            day: '2-digit',
                            month: '2-digit',
                            year: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </td>
                        <td className="p-3 text-sm capitalize">{desire.deseo_tipo}</td>
                        <td className="p-3 text-center">
                          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                            desire.resolved 
                              ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400'
                              : 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400'
                          }`}>
                            {desire.resolved ? 'Sí' : 'No'}
                          </span>
                        </td>
                        <td className="p-3 text-sm text-right font-mono">
                          {desire.heart_rate_durante ?? '—'}
                        </td>
                        <td className="p-3 text-sm text-right font-mono">
                          {desire.probabilidad_modelo 
                            ? typeof desire.probabilidad_modelo === 'number'
                              ? desire.probabilidad_modelo.toFixed(4)
                              : desire.probabilidad_modelo
                            : '—'}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};
