import { Card, CardContent } from "../../components/ui/card";

export const StatCard = ({ title, value, subtitle, icon: Icon, variant = 'default' }) => {
  const getVariantStyles = () => {
    switch (variant) {
      case 'success':
        return 'bg-emerald-50 dark:bg-emerald-950/20 border-emerald-100 dark:border-emerald-900';
      case 'warning':
        return 'bg-orange-50 dark:bg-orange-950/20 border-orange-100 dark:border-orange-900';
      case 'danger':
        return 'bg-red-50 dark:bg-red-950/20 border-red-100 dark:border-red-900';
      default:
        return 'bg-blue-50 dark:bg-blue-950/20 border-blue-100 dark:border-blue-900';
    }
  };

  const getIconColor = () => {
    switch (variant) {
      case 'success':
        return 'text-emerald-600';
      case 'warning':
        return 'text-orange-500';
      case 'danger':
        return 'text-red-500';
      default:
        return 'text-blue-500';
    }
  };

  const getSubtitleColor = () => {
    switch (variant) {
      case 'danger':
        return 'text-red-600';
      default:
        return 'text-slate-600';
    }
  };

  return (
    <Card className={`border ${getVariantStyles()}`}>
      <CardContent className="p-5">
        <div className="flex items-start justify-between mb-3">
          <p className="text-sm font-medium text-slate-700 dark:text-slate-300">{title}</p>
          {Icon && <Icon className={`h-5 w-5 ${getIconColor()}`} />}
        </div>
        <div>
          <div className="text-3xl font-bold text-slate-900 dark:text-slate-100 mb-1">{value}</div>
          {subtitle && (
            <p className={`text-xs font-medium ${getSubtitleColor()}`}>{subtitle}</p>
          )}
        </div>
      </CardContent>
    </Card>
  );
};
