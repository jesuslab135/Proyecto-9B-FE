import { Heart } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { useHeartRate } from "../../hooks/useDashboard";

export const HeartRateTimeline = ({ consumidorId }) => {
  const { data: heartRateTimeline, isLoading } = useHeartRate(consumidorId);
  const hrTableData = heartRateTimeline || [];

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Heart className="h-5 w-5 text-primary" />
          Frecuencia Cardíaca - Timeline
        </CardTitle>
        <CardDescription>
          Historial de ventanas de medición cardíaca
        </CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="flex justify-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        ) : (
          <div className="rounded-md border">
            <div className="overflow-auto max-h-96">
              <table className="w-full">
                <thead className="bg-muted/50 sticky top-0">
                  <tr className="border-b">
                    <th className="p-3 text-left text-sm font-medium">Inicio</th>
                    <th className="p-3 text-left text-sm font-medium">Fin</th>
                    <th className="p-3 text-right text-sm font-medium">HR μ</th>
                    <th className="p-3 text-right text-sm font-medium">HR σ</th>
                  </tr>
                </thead>
                <tbody>
                  {hrTableData.length === 0 ? (
                    <tr>
                      <td colSpan="4" className="p-8 text-center text-muted-foreground">
                        No hay datos disponibles
                      </td>
                    </tr>
                  ) : (
                    hrTableData.map((item, idx) => (
                      <tr key={idx} className="border-b hover:bg-muted/50 transition-colors">
                        <td className="p-3 text-sm">
                          {new Date(item.window_start).toLocaleString('es-ES', {
                            day: '2-digit',
                            month: '2-digit',
                            year: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </td>
                        <td className="p-3 text-sm">
                          {new Date(item.window_end).toLocaleString('es-ES', {
                            day: '2-digit',
                            month: '2-digit',
                            year: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </td>
                        <td className="p-3 text-sm text-right font-mono">
                          {item.heart_rate_mean}
                        </td>
                        <td className="p-3 text-sm text-right font-mono">
                          {item.heart_rate_std}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};
