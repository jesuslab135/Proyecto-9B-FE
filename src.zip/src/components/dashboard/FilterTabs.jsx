import { Tabs, TabsList, TabsTrigger } from "../../components/ui/tabs";
import { TIME_PERIOD } from "../../constants/app.constants";

export const FilterTabs = ({ value, onValueChange }) => {
  return (
    <Tabs value={value} onValueChange={onValueChange} className="w-full">
      <TabsList className="grid w-full grid-cols-3 bg-slate-200 dark:bg-slate-800 h-12">
        <TabsTrigger 
          value={TIME_PERIOD.DAY}
          className="data-[state=active]:bg-white data-[state=active]:text-slate-900 data-[state=inactive]:text-slate-600 font-medium"
        >
          Day
        </TabsTrigger>
        <TabsTrigger 
          value={TIME_PERIOD.WEEK}
          className="data-[state=active]:bg-white data-[state=active]:text-slate-900 data-[state=inactive]:text-slate-600 font-medium"
        >
          Week
        </TabsTrigger>
        <TabsTrigger 
          value={TIME_PERIOD.MONTH}
          className="data-[state=active]:bg-cyan-500 data-[state=active]:text-white data-[state=inactive]:text-slate-600 font-medium"
        >
          Month
        </TabsTrigger>
      </TabsList>
    </Tabs>
  );
};
