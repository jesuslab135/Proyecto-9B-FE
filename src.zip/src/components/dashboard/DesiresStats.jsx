import { Target } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { useDesiresStats } from "../../hooks/useDashboard";

export const DesiresStats = ({ consumidorId }) => {
  const { data: desiresStats, isLoading } = useDesiresStats(consumidorId);
  const desiresData = desiresStats || [];

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Target className="h-5 w-5 text-primary" />
          Deseos - Estadísticas
        </CardTitle>
        <CardDescription>
          Resumen de deseos por tipo y tasa de resolución
        </CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="flex justify-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        ) : (
          <div className="space-y-4">
            {desiresData.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">
                No hay estadísticas de deseos disponibles
              </p>
            ) : (
              desiresData.map((stat, idx) => (
                <div 
                  key={idx} 
                  className="flex items-center justify-between p-4 rounded-lg border bg-card hover:bg-muted/50 transition-colors"
                >
                  <div className="space-y-1">
                    <p className="font-medium capitalize">{stat.deseo_tipo}</p>
                    <p className="text-sm text-muted-foreground">
                      {stat.total_deseos} deseos registrados
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-bold text-primary">
                      {stat.porcentaje_resolucion}%
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {stat.deseos_resueltos} resueltos
                    </p>
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
};
