export const DashboardHeader = () => {
  return (
    <div className="mb-8">
      <h1 className="text-3xl font-bold text-foreground mb-1">Health Dashboard</h1>
      <p className="text-sm text-muted-foreground">
        Track your progress and stay healthy
      </p>
    </div>
  );
};
