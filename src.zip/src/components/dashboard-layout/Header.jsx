import { SidebarTrigger } from "../../components/ui/sidebar";
import { Activity } from 'lucide-react';

export const Header = () => {
  return (
    <header className="sticky top-0 z-50 w-full border-b border-border bg-card shadow-sm">
      <div className="flex h-16 items-center px-4">
        {/* Hamburger on the left */}
        <SidebarTrigger className="text-foreground hover:bg-muted" />
        
        {/* Logo in the center */}
        <div className="flex-1 flex items-center justify-center">
          <div className="flex items-center gap-2">
            <Activity className="h-7 w-7 text-primary" />
            <h1 className="text-2xl font-bold text-primary">CravingPredict</h1>
          </div>
        </div>
        
        {/* Empty space on right for balance */}
        <div className="w-10" />
      </div>
    </header>
  );
};
