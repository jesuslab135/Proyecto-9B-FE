import { SidebarProvider } from "../../components/ui/sidebar";
import { Header } from './Header';
import { AppSidebar } from './AppSidebar';

export const AppLayout = ({ children }) => {
  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full">
        <AppSidebar />
        
        <div className="flex-1 flex flex-col w-full">
          <Header />
          
          <main className="flex-1 bg-background">
            {children}
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
};
