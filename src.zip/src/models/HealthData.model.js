// OOP Model for Health Data
export class HealthDataModel {
  constructor(heartRate, cigarettesSmoked, timestamp = new Date()) {
    this._heartRate = heartRate;
    this._cigarettesSmoked = cigarettesSmoked;
    this._timestamp = timestamp;
  }

  get heartRate() {
    return this._heartRate;
  }

  set heartRate(value) {
    if (value < 0 || value > 300) {
      throw new Error('Invalid heart rate value');
    }
    this._heartRate = value;
  }

  get cigarettesSmoked() {
    return this._cigarettesSmoked;
  }

  set cigarettesSmoked(value) {
    if (value < 0) {
      throw new Error('Cigarettes smoked cannot be negative');
    }
    this._cigarettesSmoked = value;
  }

  get timestamp() {
    return this._timestamp;
  }

  isHeartRateNormal() {
    return this._heartRate >= 60 && this._heartRate <= 100;
  }

  toJSON() {
    return {
      heartRate: this._heartRate,
      cigarettesSmoked: this._cigarettesSmoked,
      timestamp: this._timestamp.toISOString(),
    };
  }
}
