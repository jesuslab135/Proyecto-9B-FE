import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import { lazy } from 'react'
import { createBrowserRouter, RouterProvider } from 'react-router-dom'
import Home from './pages/home/Home'
import Login_Register from './pages/login-register/Login_Register'
import ProtectedRoute from './components/Auth/ProtectedRoute'
import PhysicalDataForm from './components/Onboarding/PhysicalDataForm'
import FormulariosForm from './components/Onboarding/FormulariosForm'
import Habits from './pages/onboarding/Habits'
import Results from './pages/onboarding/Results'
import DashboardPage from './pages/dashboard/index'
import Settings from './pages/consumer/Settings'
import NotFound from './pages/consumer/NotFound'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { Toaster } from './components/ui/sonner'

const App = lazy(() => import('./App'));

// Create a client for React Query
const queryClient = new QueryClient()

const router = createBrowserRouter([
  // ============================================
  // Rutas SIN Layout (sin header/footer)
  // ============================================
  {
    path: '/login',
    element: <Login_Register />
  },
  {
    path: '/onboarding/physical-data',
    element: (
      <ProtectedRoute>
        <PhysicalDataForm />
      </ProtectedRoute>
    )
  },
  {
    path: '/onboarding/habitos',
    element: (
      <ProtectedRoute>
        <Habits />
      </ProtectedRoute>
    )
  },
  {
    path: '/onboarding/resultados',
    element: (
      <ProtectedRoute>
        <Results />
      </ProtectedRoute>
    )
  },
  {
    path: '/onboarding/formularios',
    element: (
      <ProtectedRoute>
        <FormulariosForm />
      </ProtectedRoute>
    )
  },
  {
    path: '/dashboard',
    element: (
      <ProtectedRoute requiredRole="consumidor">
        <DashboardPage />
      </ProtectedRoute>
    )
  },
  {
    path: '/settings',
    element: (
      <ProtectedRoute requiredRole="consumidor">
        <Settings />
      </ProtectedRoute>
    )
  },
  {
    path: '/admin/dashboard',
    element: (
      <ProtectedRoute requiredRole="administrador">
        <h1>Admin Dashboard</h1>
      </ProtectedRoute>
    )
  },
  
  // ============================================
  // Rutas CON Layout (con header/footer de landing page)
  // ============================================
  {
    element: <App />,
    children: [
      {
        path: '/',
        element: <Home />
      },
      {
        path: '/hola',
        element: <h1>Hola Mundo</h1>
      }
    ]
  },
  
  // ============================================
  // 404 Not Found - Must be last
  // ============================================
  {
    path: '*',
    element: <NotFound />
  }
])


createRoot(document.getElementById('root')).render(
  <StrictMode>
    <QueryClientProvider client={queryClient}>
      <RouterProvider router={router} />
      <Toaster />
    </QueryClientProvider>
  </StrictMode>,
)
