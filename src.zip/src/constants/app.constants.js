// Application-wide constants
export const TIME_PERIOD = {
  DAY: 'day',
  WEEK: 'week',
  MONTH: 'month',
};

export const CHART_CONFIG = {
  HEIGHT: 300,
  ANIMATION_DURATION: 750,
};

export const HEART_RATE = {
  MIN_NORMAL: 60,
  MAX_NORMAL: 100,
  WARNING_THRESHOLD: 120,
};

export const CIGARETTE_LIMITS = {
  DAILY_WARNING: 10,
  DAILY_CRITICAL: 20,
};
 
